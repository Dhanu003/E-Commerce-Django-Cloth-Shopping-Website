from django.db import models
from django.contrib.auth.models import User


# Create your models here.

class Product(models.Model):    # it is class so inherit from models.Model
    cat=((1,'Jacket'),(2,'Tops'),(3,'Shirts'),(4,'Skirts'))
    name=models.CharField(max_length=50,verbose_name="Product Name")
    price=models.FloatField()
    pdetails=models.CharField(max_length=200,verbose_name="Product Details")
    category=models.IntegerField(choices=cat)
    pimage = models.ImageField(upload_to="image", verbose_name="Product Image", default='image/default.jpg')
    color = models.CharField(max_length=20, default='N/A')
    size = models.CharField(max_length=10, default='M')
    is_active=models.BooleanField(default=True,verbose_name="Available")
    
 
class Cart(models.Model):
    uid = models.ForeignKey(User, on_delete=models.CASCADE, db_column='uid')
    pid = models.ForeignKey(Product, on_delete=models.CASCADE, db_column='pid')
    size = models.CharField(max_length=10, default='M')   # NEW
    color = models.CharField(max_length=20, default='N/A')  # NEW
    quantity = models.IntegerField(default=1)

    def __str__(self):
        return f"{self.uid.username} - {self.pid.name} ({self.size}, {self.color})"

class Address(models.Model):
    uid = models.ForeignKey(User, on_delete=models.CASCADE)
    first_name = models.CharField(max_length=100)
    last_name = models.CharField(max_length=100)
    email = models.EmailField()
    phone = models.CharField(max_length=15)
    address = models.TextField()
    city = models.CharField(max_length=100)
    zipcode = models.CharField(max_length=10)
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.first_name} {self.last_name} - {self.city}"



class Order(models.Model):
    order_id = models.CharField(max_length=100)  # e.g. ORD20240625123
    uid = models.ForeignKey(User, on_delete=models.CASCADE,db_column='uid')
    pid = models.ForeignKey(Product, on_delete=models.CASCADE, db_column='pid')
    quantity = models.PositiveIntegerField(default=1)
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"Order #{self.order_id} - {self.uid.username}"



class ContactMessage(models.Model):
    name = models.CharField(max_length=100)
    email = models.EmailField()
    subject = models.CharField(max_length=200)
    message = models.TextField()
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.name} - {self.subject}"
