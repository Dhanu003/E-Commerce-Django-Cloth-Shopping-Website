from django.shortcuts import render,HttpResponse,redirect
from django.contrib.auth.models import User
from django.contrib.auth import authenticate, login, logout
from .models import Product,Cart
from django.db.models import Q
from django.contrib.auth.decorators import login_required
from .models import Address
from .models import Order
import uuid
from django.contrib import messages
import razorpay
from django.core.mail import send_mail
from django.conf import settings
from django.db import IntegrityError



# Create your views here.

def home(request):
    print(request.user.is_authenticated)  # this will tell whenter user is logged in  or not if 0 in terminal then not logged in if 1 is there then yes.
    return render(request,'index.html') 

def about(request):
    return render(request,'about.html') 

def details(request, pid):
    p = Product.objects.filter(id=pid)
    related_products = Product.objects.filter(category=p[0].category).exclude(id=pid)[:4]

    context = {
        'products': p,
        'related_products': related_products,
        'colors': p[0].color.split(',') if ',' in p[0].color else [p[0].color],
        'sizes': p[0].size.split(',') if ',' in p[0].size else [p[0].size],
    }
    return render(request, 'products_detail.html', context)


def products(request):
    p=Product.objects.filter(is_active=True)
    print(p) #6 objects
    context={}
    context['products']=p
    return render(request,'products.html',context)

#------------------------------------------------------------------#
#register section

def register(request):
    if request.method == 'POST':
        ufname = request.POST['ufname'].strip()
        ulname = request.POST['ulname'].strip()
        uemail = request.POST['uemail'].strip()
        upass = request.POST['upass']
        ucpass = request.POST['ucpass']
        context = {}

        if ufname == "" or uemail == "" or upass == "" or ucpass == "":
            context['errmsg'] = "Please fill in all required fields."
        elif upass != ucpass:
            context['errmsg'] = "Both password fields should be the same. Please check again."
        elif User.objects.filter(username=uemail).exists():
            context['errmsg'] = "An account with this email already exists. Please try logging in."
        else:
            u = User.objects.create(username=uemail, first_name=ufname, last_name=ulname)
            u.set_password(upass)
            u.save()
            context['success'] = "Registered successfully! Please login."

        return render(request, 'register.html', context)
    else:
        return render(request, 'register.html')

#------------------------------------------------------------------#
#login section

def user_login(request):
    if request.method =='POST':
        uemail=request.POST['uemail']
        upass=request.POST['upass']
        context = {}
        if uemail == "" or upass == "":
            context['errmsg'] = "Please fill in all required fields."
            return render(request,'login.html',context)
        else:
             u= authenticate(username=uemail,password=upass) 
             if u is not None:
                 login(request,u)
                 return redirect('/')
             else:
                 context['errmsg'] = "Invalid Username and Password. Please try again"
                 return render(request,'login.html',context)
         
    else:
        return render(request,'login.html')
    

def user_logout(request):
    logout(request)
    return redirect('/')

#-----------------------------------------------------#
# filter section

def cat_filter(request,cv):    #cv => category value
    q1=Q(is_active=True)
    q2=Q(category=cv)
    p=Product.objects.filter(q1 & q2)
    context={}
    context['products']=p
    return render(request,'products.html',context)


def price_filter(request, minp, maxp):
    q1 = Q(is_active=True)
    q2 = Q(price__gte=minp, price__lte=maxp)
    p = Product.objects.filter(q1 & q2)

    context = {'products': p}
    return render(request, 'products.html', context)


def color_filter(request, color):
    q1 = Q(is_active=True)
    q2 = Q(color=color)
    p = Product.objects.filter(q1 & q2)

    context = {'products': p}
    return render(request, 'products.html', context)

def size_filter(request, size):
    q1 = Q(is_active=True)
    q2 = Q(size=size)
    p = Product.objects.filter(q1 & q2)

    context = {'products': p}
    return render(request, 'products.html', context)



  
#---------------------------------------------------------------#

  
#updated addtocart view
def addtocart(request, pid):
    if not request.user.is_authenticated:
        return redirect('/login')

    if request.method == 'POST':
        user = request.user
        product = Product.objects.get(id=pid)

        # Extract form data
        selected_size = request.POST.get('size')
        selected_color = request.POST.get('color')
        qty = int(request.POST.get('qty'))

        # Check for existing item with same size and color
        cart_item, created = Cart.objects.get_or_create(
            uid=user,
            pid=product,
            size=selected_size,
            color=selected_color,
        )

        context = {}

        if not created:
            cart_item.quantity += qty  # increment by selected qty
            cart_item.save()
            context['msg'] = "Product already in cart. Quantity updated!"
        else:
            cart_item.quantity = qty
            cart_item.save()
            context['success'] = "Product added successfully!"

        context['products'] = [product]
        return render(request, 'products_detail.html', context)

    return redirect('home')  # fallback if accessed via GET


#---------------------------------------------------------------#

#increase qty section

def increase_quantity(request, cid):
    item = Cart.objects.get(id=cid)
    item.quantity += 1
    item.save()
    return redirect('/cart')

#---------------------------------------------------------------#

#decrease qty section  

def decrease_quantity(request, cid):
    item = Cart.objects.get(id=cid)
    if item.quantity > 1:
        item.quantity -= 1
        item.save()
    else:
        item.delete()
    return redirect('/cart')


#---------------------------------------------------------------#


#updated view_cart
def view_cart(request):
    cart_items = Cart.objects.filter(uid=request.user)
    
    for item in cart_items:
        item.total = item.pid.price * item.quantity 

    subtotal = sum(item.total for item in cart_items)
    shipping = 10 if cart_items else 0
    total = subtotal + shipping

    return render(request, 'cart.html', {
        'products': cart_items,
        'subtotal': subtotal,
        'shipping': shipping,
        'total': total
    })


#---------------------------------------------------------------#
  
    
# removing product from cart


def removecart(request, cid):
    if request.user.is_authenticated:
        try:
            # Find the cart item and delete it (not the product itself)
            cart_item = Cart.objects.get(id=cid, uid=request.user)
            cart_item.delete()
            msg = "Product removed from cart!"
        except:
            msg = "Something went wrong while removing the product."

        # After removal, fetch remaining items in the cart
        cart_items = Cart.objects.filter(uid=request.user)

        context = {
            'success': msg,
            'products': cart_items  # cart items list
        }
        return render(request, 'cart.html', context)

    else:
        return redirect('/view_cart')

#---------------------------------------------------------------#

#checkout page 
import uuid
from django.db import IntegrityError

def generate_unique_order_id():
    for _ in range(5):  # Try 5 times max
        order_id = "ORD" + uuid.uuid4().hex[:10].upper()
        if not Order.objects.filter(order_id=order_id).exists():
            return order_id
    raise Exception("Could not generate a unique order ID after multiple tries")

from django.db import IntegrityError

@login_required
def checkout(request):
    cart_items = Cart.objects.filter(uid=request.user)

    for item in cart_items:
        item.total = item.pid.price * item.quantity

    subtotal = sum(item.total for item in cart_items)
    shipping = 10 if cart_items else 0
    tax = 3
    total = subtotal + shipping + tax

    user_address = Address.objects.filter(uid=request.user).order_by('-created_at').first()

    if request.method == 'POST' and request.POST.get('order_submit') == '1':
        if cart_items.count() == 0:
            return redirect('/cart')

        fname = request.POST['fname']
        lname = request.POST['lname']
        email = request.POST['email']
        phone = request.POST['phone']
        addr = request.POST['address']
        city = request.POST['city']
        zip = request.POST['zipcode']

        Address.objects.create(
            uid=request.user,
            first_name=fname,
            last_name=lname,
            email=email,
            phone=phone,
            address=addr,
            city=city,
            zipcode=zip
        )

        try:
            order_id = generate_unique_order_id()

            for item in cart_items:
                Order.objects.create(
                    order_id=order_id,
                    uid=request.user,
                    pid=item.pid,
                    quantity=item.quantity
                )

            cart_items.delete()
            return redirect('placeorder')

        except IntegrityError as e:
            print("Error inserting order:", e)
            return HttpResponse("Error placing order. Please try again.", status=500)

    return render(request, 'checkout.html', {
        'products': cart_items,
        'subtotal': subtotal,
        'shipping': shipping,
        'tax': tax,
        'total': total,
        'user_address': user_address
    })




#----------------------------------------------------------------------#
# views.py

# views.py
@login_required
def placeorder(request):
    latest_order = Order.objects.filter(uid=request.user).order_by('-created_at').first()
    message = None

    if request.GET.get('continue') == '1':
        message = "🛒 Please complete your payment or click 'Make Payment' to proceed."

    if latest_order:
        order_id = latest_order.order_id
        order_date = latest_order.created_at.strftime('%Y-%m-%d')
        ordered_items = Order.objects.filter(order_id=order_id)
        address = Address.objects.filter(uid=request.user).order_by('-created_at').first()

        subtotal = sum(item.pid.price * item.quantity for item in ordered_items)
        shipping = 10 if ordered_items else 0
        tax = 3
        total = subtotal + shipping + tax

        return render(request, 'placeorder.html', {
            'latest_order_id': order_id,
            'order_date': order_date,
            'ordered_items': ordered_items,
            'address': address,
            'subtotal': subtotal,
            'shipping': shipping,
            'tax': tax,
            'total': total,
            'message': message,
        })

    # Even if no order, show the page with a message
    messages.warning(request, "⚠️ No active orders found.")
    return render(request, 'placeorder.html', {'ordered_items': []})



#cancel order

@login_required
def cancel_order(request):
    latest_order = Order.objects.filter(uid=request.user).order_by('-created_at').first()

    if latest_order:
        order_id = latest_order.order_id
        # Delete all items with this order ID
        Order.objects.filter(order_id=order_id).delete()
        messages.error(request, "❌ Your order has been cancelled.")

    return redirect('placeorder')


#payment page 

@login_required
def payment_page(request):
    # Get latest order
    latest_order = Order.objects.filter(uid=request.user).order_by('-created_at').first()
    
    if not latest_order:
        return redirect('placeorder')  # No order found

    # Get all items in that order ID
    ordered_items = Order.objects.filter(order_id=latest_order.order_id)
    
    # Calculate total
    subtotal = sum(item.pid.price * item.quantity for item in ordered_items)
    shipping = 10 if ordered_items else 0
    tax = 3
    total = subtotal + shipping + tax
    
    # Razorpay requires amount in paise
    amount_in_paise = int(total * 100)

    client = razorpay.Client(auth=("rzp_test_pjmfONoAV5hhRJ", "2qLFlWxOv0vaA1jxWEEHwbcA"))
    data = {
        "amount": amount_in_paise,
        "currency": "INR",
        "receipt": latest_order.order_id,
        "payment_capture": 1
    }
    
    try:
        payment = client.order.create(data=data)
        print("Razorpay Order Created:", payment)
    except Exception as e:
        print(" Razorpay Error:", e)
        return HttpResponse("Payment initialization failed", status=500)

    # Render payment page with amount, order_id, etc.
    return render(request, 'payment.html', {
        "razorpay_order": payment,
        "amount": total,
        "order_id": latest_order.order_id
        
    })


from .models import Order

@login_required
def sendusermail(request):
    latest_order = Order.objects.filter(uid=request.user).order_by('-created_at').first()
    
    if latest_order:
        try:
            send_mail(
                subject="✅ Your Order Has Been Placed - ShopMart",
                message=f"Dear {request.user.first_name},\n\nYour order ({latest_order.order_id}) has been successfully placed!\n\nThank you for shopping with ShopMart.",
                from_email="yourapp@example.com",
                recipient_list=[request.user.email],
                fail_silently=False,
            )
            messages.success(request, "✅ Confirmation email has been sent.")
        except Exception as e:
            print("Mail sending failed:", e)
            messages.error(request, "❌ Failed to send confirmation email.")
    else:
        messages.warning(request, "⚠️ No recent order found.")

    return redirect('placeorder')


#contact page


from .models import ContactMessage

def contact(request):
    if request.method == "POST":
        name = request.POST.get('name')
        email = request.POST.get('email')
        subject = request.POST.get('subject')
        message = request.POST.get('message')

        if name and email and subject and message:
            ContactMessage.objects.create(
                name=name, email=email,
                subject=subject, message=message
            )
            messages.success(request, "✅ Your message has been sent successfully!")
            return redirect('contact')
        else:
            messages.error(request, "❌ Please fill in all the fields.")

    return render(request, 'contact.html')

