
from django.urls import path
from shop_app import views
from shopmart import settings
from django.conf.urls.static import static

urlpatterns = [
    path('', views.home, name='home'),
    path('about/', views.about, name='about'),
    path('pdetail/<pid>', views.details,name='pdetail'),
    path('product', views.products,name='product'),
    path('register',views.register),
    path('login',views.user_login),
    path('logout',views.user_logout),
    path('cat_filter/<cv>',views.cat_filter,name='cat_filter'),
    path('price_filter/<minp>-<maxp>', views.price_filter,name='price_filter'),
    path('color_filter/<color>', views.color_filter,name='color_filter'),
    path('size_filter/<size>', views.size_filter, name='size_filter'),   
    path('addtocart/<pid>',views.addtocart, name='addtocart'),
    path('cart', views.view_cart, name='showcart'),
    path('removecart/<int:cid>/', views.removecart),
    path('increase/<int:cid>/', views.increase_quantity, name='increase'),
    path('decrease/<int:cid>/', views.decrease_quantity, name='decrease'),
    path('checkout/', views.checkout, name='checkout'),
    path('placeorder/', views.placeorder, name='placeorder'),
    path('cancel-order/', views.cancel_order, name='cancel_order'),
    path('payment/', views.payment_page, name='payment'),
    path('sendmail/', views.sendusermail, name='sendusermail'),
    path('contact/', views.contact, name='contact'),


]

if settings.DEBUG:
    urlpatterns +=static(settings.MEDIA_URL,document_root=settings.MEDIA_ROOT)
